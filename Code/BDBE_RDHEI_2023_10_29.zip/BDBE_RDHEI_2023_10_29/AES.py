from Crypto.Cipher import AES
from binascii import b2a_hex, a2b_hex


def add_to_16(text):
    if len(text) % 32:
        add = 32 - (len(text) % 32)
    else:
        add = 0
    text = text + ('0' * add)
    return text


def encrypt(text, key, iv):
    text = add_to_16(text)
    text = a2b_hex(text.encode('utf-8'))
    key = key.encode('utf-8')
    iv = iv.encode('utf-8')
    mode = AES.MODE_CBC
    cryptos = AES.new(key, mode, iv)
    cipher_text = cryptos.encrypt(text)
    return b2a_hex(cipher_text).decode('utf-8')
    # return cipher_text.decode('')

    # return cipher_text

def decrypt(text, key, iv):
    text = add_to_16(text)
    text = a2b_hex(text.encode('utf-8'))
    key = key.encode('utf-8')
    iv = iv.encode('utf-8')
    mode = AES.MODE_CBC
    cryptos = AES.new(key, mode, iv)
    plain_text = cryptos.decrypt(text)
    return b2a_hex(plain_text).decode('utf-8')