function [plaintext_bitstream] = AES_dec(ciphertext_bitstream, key, iv)
% 函数说明：AES解密
% 输入：ciphertext_bitstream（二进制密文串）, key & iv （解密密钥）
% 输出：plaintext_bitstream（二进制明文串）

    hexstream = bit2hex(ciphertext_bitstream);
    
    plaintext_hexstream = char(py.AES.decrypt(hexstream,key,iv));
    
    plaintext_bitstream = hex2bit(plaintext_hexstream);

end
