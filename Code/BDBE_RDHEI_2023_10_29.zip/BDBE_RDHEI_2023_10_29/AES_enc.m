function [ciphertext_bitstream] = AES_enc(plaintext_bitstream, key, iv)
% 函数说明：AES加密
% 输入：plaintext_bitstream（二进制明文串）, key & iv （加密密钥）
% 输出：ciphertext_bitstream（二进制密文串）

    hexstream = bit2hex(plaintext_bitstream);

    encrypted_hexstream = char(py.AES.encrypt(hexstream,key,iv));

    ciphertext_bitstream = hex2bit(encrypted_hexstream);

end
