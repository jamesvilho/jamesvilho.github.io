function [blksizeChoose, compressAns] = BDBE(EI)
% 函数说明：使用BDBE压缩EI的18个位面
% 输入：EI（9-bit 误差图像）
% 输出：blksizeChoose（18个位面选择的分块大小）, compressAns（18个位面的压缩结果）

    [m, n] = size(EI);
    blksizeChoose = zeros(1, 18);
    compressAns = cell(1, 18);

    pixels = m * n / 2;
    half_row = m / 2;
    
    %% 将图像EI的 十进制值 转为 9-bit 二进制形式
    total_pixels = m * n;
    EI = reshape(EI', total_pixels, 1); % 将EI按行转为列向量

    EI_binary = zeros(total_pixels, 9); % 将EI每个值转为二进制
    for i = 1:total_pixels
        EI_binary(i,:) = dec2bin(EI(i,1), 9) - '0';   % 第1列 是 最高位面, 第9列是最低位面
    end
    
    %% 提取EI的18个位面 
    BitPlanes = cell(1, 18);
    for i = 1:9
        arr = EI_binary(:,i);      
        BitPlanes{2*(i-1)+1} = reshape(arr(1:pixels, 1), n, half_row)';  % 位面是 m/2 * n 的形式
        BitPlanes{2*(i-1)+2} = reshape(arr(pixels+1:end, 1), n, half_row)';
    end
    
    %% 压缩EI的18个位面
    len = 0;
    for kid = 1:18
        plane = BitPlanes{kid};
        n1 = length(find(plane(:) == 1));
        [P1, blksize] = decideBlkSize(n1, pixels);
%         fprintf("bit-plane %d: P1 = %.2e, S = %d\n", kid, P1, blksize);
        
        if blksize == 1     % 不尝试编码
%             fprintf("bit-plane %d: un-encodable\n", kid);
            blksizeChoose(kid) = 1;
            compressAns{kid} = reshape(plane', 1, pixels);
            len = len + pixels;
        else                % 尝试编码
            minCompAns = compressBitPlane(plane, blksize);
            minLen = length(minCompAns);

            if minLen >= pixels
%                 fprintf("bit-plane %d: un-encodable\n", kid);
                blksizeChoose(kid) = 1;
                compressAns{kid} = reshape(plane', 1, pixels);
                len = len + pixels;
            else
%                 fprintf("bit-plane %d: encodable, len = %d\n", kid, minLen);
                blksizeChoose(kid) = blksize;
                compressAns{kid} = minCompAns;
                len = len + minLen;
            end
        end
           
    end
    
end
