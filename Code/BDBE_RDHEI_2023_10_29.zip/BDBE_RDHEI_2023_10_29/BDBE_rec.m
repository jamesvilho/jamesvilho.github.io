function [EI8, LM] = BDBE_rec(blksizeChoose, compressAns, m, n)
% 函数说明：BDBE解压缩EI的18个位面
% 输入：blksizeChoose（18个位面选择的分块大小）, compressAns（18个位面的压缩结果）, m（恢复图像的行数）, n（恢复图像的列数）
% 输出：EI8（误差图像EI的低8位面构成的十进制矩阵）, LM（误差图像EI的第9位面）

    pixels = m * n / 2;
    total_pixels = m * n;
    
    %% EI的9位面二进制形式
    EI = zeros(total_pixels, 9);      
    for k = 0:8
        bitplane = zeros(pixels, 2);   % 第一列：上半位面, 第二列：下半位面
        for id = 1:2                  
            kid = 2 * k + id;  % 1,2  3,4 ... 17,18
            if blksizeChoose(kid) ~= 1         % 可编码位面的解压缩
                half_vec = compressBitPlane_rec(compressAns{kid}, blksizeChoose(kid), m/2, n);  
            else                           
                half_vec = compressAns{kid}';  % 按位面扫描顺序得到的列向量
            end
            bitplane(:, id) = half_vec;
        end
        bitplane = reshape(bitplane, total_pixels, 1);
        EI(:,k+1) = bitplane;
    end

    %% LM
    LM = reshape(EI(:, 1), n, m)';
    
    %% EI8
    EI8 = zeros(total_pixels, 1);
    for i = 1:total_pixels
        EI8(i) = bit2dec(EI(i,2:9));
    end
        
    EI8 = reshape(EI8, n, m)';

    
end
