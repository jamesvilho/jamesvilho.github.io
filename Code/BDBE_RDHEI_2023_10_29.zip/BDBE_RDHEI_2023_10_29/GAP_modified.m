function [pred] = GAP_modified(p0, p1, p2, p3, p4, p5, p6, p7, p8)
% 函数说明：预测误差生成阶段
% 输入：像素p的9个邻居像素
%    p6 p7 p8
% p2 p3 p4 p5
% p0 p1 p
% 输出：pred（像素p的预测结果）


    dv = abs(p1-p3) + abs(p3-p6) + abs(p4-p7) + abs(p5-p8);
    dh = abs(p0-p1) + abs(p2-p3) + abs(p3-p4) + abs(p4-p5);
    
    d = dv - dh;
    
    u = (p1 + p4)/2 + (p5 - p3)/4;
    
    if d > 80
        ref = p1;
    elseif d > 32
        ref = (p1 + u)/2;
    elseif d > 8
        ref = (p1 + 3 * u)/4;
    elseif d >= -8
        ref = u;
    elseif d >= -32
        ref = (p4 + 3 * u)/4;
    elseif d >= -80
        ref = (p4 + u)/2;
    else
        ref = p4;
    end
    
    pred = ceil(ref);

end