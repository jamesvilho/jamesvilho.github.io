function [out] = MED(upleft, up, left)
% 函数说明：MED预测器 median edge detector
% 输入：upleft (左上方相邻像素值), up (上方相邻像素值), left (左边相邻像素值)
% 输出：out (像素值预测结果)

    if upleft <= min(left, up)
        out = max(left, up);
    elseif upleft >= max(left, up)
        out = min(left, up);
    else
        out = left + up - upleft;
    end

end

