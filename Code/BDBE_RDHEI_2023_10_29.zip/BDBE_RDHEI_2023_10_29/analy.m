function [strImg, head, dataLen] = analy(I)
% 函数说明：分析密文图像
% 输入：I（密文图像 或 标记的密文图像）
% 输出：strImg（图像I的比特串）, head（额外数据的起始嵌入位置）, dataLen（额外数据的最大嵌入长度）

    strImg = readImgStr(I); % 逐位面,按行提取的比特
    [m, n] = size(I);
    
    %% SI的前3部分
    pos = 1;
    len = 5;
    K = bit2dec(strImg(pos : pos+len-1));   % 不能编码的位面个数 K
    
    len_SI_3 = 5 + 5 * K + 3 * (18-K);      % SI的前3部分的总长
    
    %% SI的第4部分：可编码位面的压缩结果长度
    pos = len_SI_3 + 1;                     
    Cnum = 18 - K;
    
    SumCLen = 0;    % 可编码位面的编码结果总长
    len = ceil(log2(m * n/2));
    for i = 1:Cnum
        SumCLen = SumCLen + bit2dec(strImg(pos : pos+len-1));
        pos = pos + len;
    end
    
    %% SI的第5部分：e∉[-128,127]的像素个数 keepNum
    len = ceil(log2(m*n));
    keepNum = bit2dec(strImg(pos : pos+len-1));   
    pos = pos + len;
    
    %% EMI
    head = pos;    % EMI的起始位置
    
    len_MI = keepNum * 8 + SumCLen + K * m/2 * n;     % MI = T||C||U
    len_EMI = ceil(len_MI/128) * 128;                 % AES加密后的长度
    
    %% 额外数据
    head = head + len_EMI;           % 额外数据的起始嵌入位置
    
    dataLen = m * n * 8 - head + 1;  % 额外数据的最大嵌入长度
end