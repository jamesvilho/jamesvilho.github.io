function [value] = bit2dec(bitstream)
% 函数说明：二进制转十进制
% 输入：bitstream（01向量）
% 输出：value（十进制结果）

    value = 0;
    len = length(bitstream);
    for i = 1:len
        value = value + bitstream(i)*(2^(len-i));
    end
end