function [hexstream] = bit2hex(bitstream)
% 函数说明：二进制转16进制
% 输入：bitstream（长度为4的整数倍的二进制串）
% 输出：hexstream（16进制串）

    bit_len = length(bitstream);
    if mod(bit_len, 4) ~= 0
        error("bit2hex: input length error\n");  % 确保输入长度已填充至4的整数倍
    end
    hex_len = bit_len / 4;      
    hexstream = char(zeros(1, hex_len));
   
    arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'];
    for i = 1:hex_len
        v = bitstream((i-1)*4+1:i*4);
        dec = v(1) * 8 + v(2) * 4 + v(3) * 2 + v(4);
        hexstream(i) = arr(dec+1);
    end

end

