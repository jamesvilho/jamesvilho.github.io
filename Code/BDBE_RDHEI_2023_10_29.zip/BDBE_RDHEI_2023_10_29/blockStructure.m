function [code] = blockStructure(Str, n1, Na)
% 函数说明：得到Type-II类型块的编码 BN||BD
% 输入：Str（块的一维形式）, n1（块中1的个数）, Na（阈值）
% 输出：code（块的编码 BN||BD）
    
    %% BN: 编码1的个数
    if n1 < Na
        BN = [ones(1, n1), 0];
    elseif n1 == Na
        BN = ones(1, Na);
    else
        error("blockStructure: input n1 error\n");
    end
    
    %% BD: 编码1的位置
    BD = [];
    for i = 1:n1
        len = length(Str);
        if mod(i,2) == 1
            id = find(Str(:) == 1);
            id = id(1);
            Str = Str(id+1:end);
        else
            Str = flip(Str);
            id = find(Str(:) == 1);
            id = id(1);
            Str = Str(id+1:end);
            Str = flip(Str);
        end
        Li = max(1, ceil(log2(len-(n1-i))));
        BDi = dec2bin(id-1, Li)-'0';
        BD = [BD, BDi];
    end

    %%
    code = [BN, BD];
end