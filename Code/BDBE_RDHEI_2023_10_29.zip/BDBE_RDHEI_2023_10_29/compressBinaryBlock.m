function [compressAns, blkType] = compressBinaryBlock(blk)
% 函数说明：BDBE压缩1个二值块
% 输入：blk（待压缩的块）
% 输出：compressAns（块的压缩结果）, blkType（块类型）
% blkType: 1 (Type-I), 2 (Type-II && z==0), 3 (Type-II && z>0)

    [blksize, ~] = size(blk);
    Na = getNa(blksize);
    
    z = length(find(blk(:) == 1));
    
    Str = reshape(blk', 1, blksize * blksize);
    if z == 0
        compressAns = [0,0];
        blkType = 2;
    elseif z <= Na
        compressAns = [0, blockStructure(Str, z, Na)];
        blkType = 3;
    else
        compressAns = [1, Str];
        blkType = 1;
    end
    
end