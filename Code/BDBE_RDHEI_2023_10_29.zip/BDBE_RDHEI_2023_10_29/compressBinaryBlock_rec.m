function [blk, pos_add] = compressBinaryBlock_rec(str, blksize)
% 函数说明：BDBE解压缩1个块
% 输入：str（块的压缩结果）, blksize（块大小）
% 输出：blk（解压缩后的二值块）, pos_add（本块的实际编码长度）

    pixels = blksize * blksize;
    
    if str(1) == 0    % 可编码块 Type-II
        
        if str(2) == 0  % 全0
            blk = zeros(blksize, blksize); 
            pos_add = 2;
        else            % 有1
            blkstr = zeros(1, pixels);
            
            %% 解码块中1的个数 n1
            Na = getNa(blksize);
            if length(str(2:end)) < Na
                arr = str(2:end);
            else
                arr = str(2:Na+1);
            end
            id0 = find(arr(:) == 0, 1, 'first'); % 从str第2位开始, 找到str中第一个0的位置
            if isempty(id0)
                n1 = Na;
                pos = 2 + Na;
            else
                n1 = id0(1) - 1;
                pos = 3 + n1;
            end
            
            %% 解码块中1的位置
            rl = 1;
            rh = pixels;
            
            for i = 1:n1
                len = rh - rl + 1;
                li = max(1, ceil(log2(len-(n1-i))));
                BDi = str(pos : pos+li-1);
                pos = pos + li;

                Ii = bit2dec(BDi);
                if bitand(i,1)
                    Ii = rl+Ii;
                    rl = Ii+1;
                else
                    Ii = rh-Ii;
                    rh = Ii-1;
                end
                blkstr(Ii) = 1;
            end
            
            blk = reshape(blkstr, blksize, blksize)';
            pos_add = pos-1;
        end
    else         % 不可编码块 Type-I
        blkstr = str(1, 2 : pixels+1);
        blk = reshape(blkstr, blksize, blksize)';
        pos_add = 1 + pixels;
    end

end