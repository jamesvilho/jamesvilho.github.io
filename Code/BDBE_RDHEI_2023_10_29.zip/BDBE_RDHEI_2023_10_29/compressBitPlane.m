function [out] = compressBitPlane(plane, blksize)
% 函数说明：BDBE压缩1个位面
% 输入：plane（待压缩位面）, blksize（分块大小）
% 输出：out（位面的压缩结果）

    [M, N] = size(plane);

    blkRow = M / blksize;
    blkCol = N / blksize;

    % 分块
    B = mat2cell(plane, blksize * ones(1, blkRow), blksize * ones(1, blkCol));

    % 每块进行压缩
    [temp, blkType] = cellfun(@compressBinaryBlock, B, 'UniformOutput', false);
    
    % 各块的压缩结果连接
    temp = reshape(temp', 1, blkRow * blkCol);
    out = cell2mat(temp);
    
%     % 查看Type-I, Type-II(n1 == 0) 以及 Type-II(n1>0)的分布情况
%     blkType = cell2mat(blkType);
%     tabulate(blkType(:));
end