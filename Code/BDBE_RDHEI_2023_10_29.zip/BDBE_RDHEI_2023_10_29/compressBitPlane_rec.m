function [plane] = compressBitPlane_rec(compressAns, blksize, M, N)
% 函数说明：BDBE解压缩1个位面
% 输入：compressAns（位面的压缩结果）, blksize（位面的分块大小）,  M（位面的行数）, N（位面的列数）
% 输出：plane（解压缩后的位面）

    plane = zeros(M, N);
    blkRow = M / blksize;
    blkCol = N / blksize;
    
    % 分块
    B = mat2cell(plane, blksize * ones(1, blkRow), blksize * ones(1, blkCol));
    
    maxLen = blksize * blksize * 2;   % 足够涵盖该块的编码结果
    
    pos = 1;
    for i = 1:blkRow
        for j = 1:blkCol
            giveLen = min(maxLen, length(compressAns) - pos + 1);    % 简化传入的长度
            [B{i,j}, pos_add] = compressBinaryBlock_rec(compressAns(pos : pos + giveLen - 1), blksize);
            
            pos = pos + pos_add;
        end
    end
    plane = cell2mat(B);
    
    % 按行转成一列
    plane = reshape(plane', M * N, 1);

end