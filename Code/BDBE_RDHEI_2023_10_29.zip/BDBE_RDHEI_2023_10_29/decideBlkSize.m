function [P1, S] = decideBlkSize(N1, total)
% 函数说明：决定位面分块大小
% 输入：N1（位面中1的个数）, total（位面中符号总数）
% 输出：S（块大小）

    P1 = N1/total;
    
    if P1 <= 0.000064850
        S = 256;
    elseif P1 <= 0.00024796
        S = 128;
    elseif P1 <= 0.00092697
        S = 64;
    elseif P1 <= 0.0034599
        S = 32;
    elseif P1 <= 0.014309
        S = 16;
    elseif P1 <= 0.086376
        S = 8;
    elseif P1 <= 0.34893    
        S = 4;
    else
        S = 1; 
    end
    
end