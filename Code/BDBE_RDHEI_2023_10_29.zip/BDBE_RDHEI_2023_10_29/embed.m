function [EM] = embed(E, embed_bits, data_key, data_iv)
% 函数说明：嵌入数据
% 输入：E（密文图像）, embed_bits（待嵌入数据）, data_key & data_iv（数据加密秘钥）
% 输出：EM（标记的密文图像）

    [strImg, head, dataLen] = analy(E);  % 密文图像分析

    if length(embed_bits) > dataLen
        error("embed: cannot embed too much data");
    end
    embed_bits_encrypted = AES_enc(embed_bits, data_key, data_iv);     % 数据加密 
    
    strImg(head : head+length(embed_bits_encrypted)-1) = embed_bits_encrypted;  % 数据写入
    
    [m, n] = size(E);
    EM = strWriteImg(strImg, m, n);   % 比特串转图像

end