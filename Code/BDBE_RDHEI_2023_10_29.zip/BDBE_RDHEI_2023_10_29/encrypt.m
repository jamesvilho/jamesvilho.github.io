function [E, ER] = encrypt(I, image_key, image_iv)
% 函数说明：图像加密
% 输入：I（原始灰度图像）, image_key & image_iv（图像加密秘钥）
% 输出：E（密文图像）

    [m, n] = size(I);
    
    [EI, T] = generateEI(I);                                                  % 生成误差图像EI

    [blksizeChoose, compressAns] = BDBE(EI);                                  % 对EI的18个位面进行压缩

    [E, ER] = generateE(blksizeChoose, compressAns, T, m, n, image_key, image_iv);  % 生成密文图像

end