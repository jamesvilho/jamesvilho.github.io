function [data_decrypted] = extract(EM, len, data_key, data_iv)
% 函数说明：提取数据
% 输入：EM（标记的密文图像）, len（数据长度）, data_key & data_iv（数据加密秘钥）
% 输出：data_decrypted（解密的秘密数据）

    [strImg, head, dataLen] = analy(EM);    % 密文图像分析

    if len > dataLen
        error("extract: 数据长度越界\n");
    end
    data = strImg(head : head+len-1);       % 数据提取
    data_decrypted = AES_dec(data, data_key, data_iv);    % 数据解密
end