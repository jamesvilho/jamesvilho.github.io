function [E, ER] = generateE(blksizeChoose, compressAns, T, m, n, image_key, image_iv)
% 函数说明：生成密文图像
% 输入：blksizeChoose（18个位面选择的分块大小）, compressAns（18个位面的压缩结果）, T（二进制串：误差e∉[-128,127]的像素的原值）, m（密文图像的行数）, n（密文图像的列数）, image_key & image_iv（图像加密秘钥）
% 输出：E（密文图像）
    
    K = length(find(blksizeChoose==1));

    ids = 1:18;
    id_uncompress = ids(blksizeChoose==1);  
    id_compress = ids(blksizeChoose~=1);
    blksize_use = blksizeChoose(blksizeChoose~=1);
    
    %% SI
    len_SI = 41 + 3 * K + (19-K) * ceil(log2(m*n));
    SI = zeros(1, len_SI);
    
    % 1. 不可编码的位面个数
    pos = 1; len = 5;
    SI(pos : pos+len-1) = dec2bin(K, 5)-'0';         
    pos = pos + len;
    
    % 2. 不可编码位面的下标
    len = 5 * K;
    arr = dec2bin(id_uncompress, 5)-'0';
    SI(pos : pos+len-1) = reshape(arr', 1, len);        
    pos = pos + len;
    
    % 3. 可编码的位面分块大小
    len = 3 * length(id_compress);
    arr = log2(blksize_use) - 2;
    arr = dec2bin(arr, 3)-'0';
    SI(pos : pos+len-1) = reshape(arr', 1, len);        
    pos = pos + len;
    
    % 4. 可编码位面的压缩结果长度 
    eachLen = ceil(log2(m * n/2));
    len = eachLen * length(id_compress);
    arr = cellfun(@numel, compressAns);            
    arr = arr(id_compress);
    arr = dec2bin(arr, eachLen) - '0';
    SI(pos : pos+len-1) = reshape(arr', 1, len);
    pos = pos + len;
    
    % 5. e∉[-128,127]的像素个数
    len = ceil(log2(m * n));
    arr = length(T)/8;                         
    arr = dec2bin(arr, len) - '0';
    SI(pos : pos+len-1) = arr;
    
    %% MI
    MI = [T, cell2mat(compressAns)];
    

    %% EMI
    add_len = ceil(length(MI)/128) * 128 - length(MI);  % 填充至128的整数倍长度
    MI = [MI, zeros(1, add_len)];

    EMI = AES_enc(MI, image_key, image_iv);             % AES加密

    freeNum = m * n * 8 - len_SI - length(EMI);
    ER = freeNum/m/n;
    
    embedRandom = randi([0 1], 1, freeNum);
    
    E_01 = [SI, EMI, embedRandom];                      % 密文图像E的二进制串
    
    E = strWriteImg(E_01, m, n);                        % 二进制串转图像
    
    fprintf("k = %d, L_SI = %d, L_T = %d, L_EMI = %d\n", K, len_SI, length(T), length(EMI));
    fprintf("ER = %.3f\n", ER);
end