function [EI, T] = generateEI(I)
% 函数说明：预测误差生成阶段
% 输入：I（原始灰度图像）
% 输出：EI（9-bit 误差图像）, T（二进制串：误差e∉[-128,127]的像素的原值）

    [m, n] = size(I);
    I = double(I);

    %% 计算预测误差
    errorArr = zeros(m, n);
    
    errorArr(1,1) = I(1,1);
    
    % 第一行
    ref = I(1,1:n-1);
    errorArr(1, 2:n) = I(1, 2:n) - ref;
    
    % 第一列
    ref = I(1:m-1, 1);
    errorArr(2:m, 1) = I(2:m, 1) - ref;
    
    % 最后一列
    ref = I(1:m-1, n);
    errorArr(2:m, n) = I(2:m, n) - ref;
    
    % 第二行
    i = 2;
    for j = 2:n-1         
        ref = MED(I(i-1,j-1), I(i,j-1), I(i-1,j));
        errorArr(i,j) = I(i,j) - ref;
    end
    
    % 第二列
    j = 2;
    for i = 3:m       
        ref = MED(I(i-1,j-1), I(i,j-1), I(i-1,j));
        errorArr(i,j) = I(i,j) - ref;
    end
    
    % 其余像素
    for i = 3:m
        for j = 3:n-1
            ref = GAP_modified(I(i,j-2),I(i,j-1),I(i-1,j-2),I(i-1,j-1),I(i-1,j),I(i-1,j+1),I(i-2,j-1),I(i-2,j),I(i-2,j+1));
            errorArr(i,j) = I(i,j) - ref;
        end
    end

    
    %% 误差编码
    LM = zeros(m, n);
    T = [];
    codeArr = zeros(m, n);
    exceed_num = 0;
    for j = 1:n
        for i = 1:m
            if (errorArr(i,j) >= 128) || (errorArr(i,j) < -1 * 128)
                LM(i,j) = 1;
                T = [T, dec2bin(I(i,j), 8)-'0'];
%                 fprintf("T: %d, %d, %d\n", i, j, I(i,j));
                codeArr(i,j) = 0;
                exceed_num = exceed_num + 1;
            else
                LM(i,j) = 0;
                codeArr(i,j) = transCode(errorArr(i,j));
            end
        end
    end
    
    %% 9-bit 误差图像 EI
    EI = zeros(m, n);
    for i = 1:m
        for j = 1:n
            EI(i,j) = codeArr(i,j) + LM(i,j) * 2^8;
        end
    end

end