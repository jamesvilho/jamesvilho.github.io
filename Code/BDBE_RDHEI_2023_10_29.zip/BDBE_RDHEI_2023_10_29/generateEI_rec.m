function [recI] = generateEI_rec(EI8, LM, T)
% 函数说明：恢复原始图像
% 输入：EI8（误差图像EI的低8位面构成的十进制矩阵）, LM（标识像素是否满足e∉[-128,127]）, T（误差e∉[-128,127]的像素的原值序列）
% 输出：recI（恢复的图像）

    %% 编码转换
    [m, n] = size(EI8);
    for i = 1:m
        for j = 1:n
            EI8(i,j) = transCode_rec(EI8(i,j));
        end
    end

    recI = EI8;
    
    %% 恢复 location_map == 1 位置的像素值
    keepNum = length(T)/8;
    T = reshape(T, 8, keepNum)';
    value = zeros(1, keepNum);
    for i = 1:keepNum
        value(i) = bit2dec(T(i,:));
    end
    recI(LM == 1) = value;
    
    %% 像素预测 恢复 location_map == 0 位置的像素值

    ref = recI(1,1);
    i = 1;
    for j = 2:n        % 第一行
        if LM(i,j) == 0
            recI(i,j) = recI(i,j) + ref;
        end
        ref = recI(i,j);
    end
    
    ref = recI(1,1);
    j = 1;
    for i = 2:m         % 第一列
        if LM(i,j) == 0
            recI(i,j) = recI(i,j) + ref;
        end
        ref = recI(i,j);
    end
    
    ref = recI(1,n);
    j = n;
    for i = 2:m         % 最后一列
        if LM(i,j) == 0
            recI(i,j) = recI(i,j) + ref;
        end
        ref = recI(i,j);
    end
    
    i = 2;
    for j = 2:n-1       % 第二行
        if LM(i,j) == 0
            recI(i,j) = recI(i,j) + MED(recI(i-1,j-1), recI(i,j-1), recI(i-1,j));
        end
    end
    
    j = 2;
    for i = 3:m         % 第二列
        if LM(i,j) == 0
            recI(i,j) = recI(i,j) + MED(recI(i-1,j-1), recI(i,j-1), recI(i-1,j));
        end
    end
    
    for i = 3:m         % 其余位置
        for j = 3:n-1 
            if LM(i,j) == 0
                ref = GAP_modified(recI(i,j-2), recI(i,j-1), recI(i-1,j-2),recI(i-1,j-1),recI(i-1,j),recI(i-1,j+1),recI(i-2,j-1),recI(i-2,j), recI(i-2,j+1));
                recI(i,j) = recI(i,j) + ref;
            end
        end
    end
    
end