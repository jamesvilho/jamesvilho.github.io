function [Na] = getNa(blksize)
% 函数说明：Na阈值的确定
% 输入：blksize（块大小）
% 输出：Na（判断块类型的阈值）

    switch blksize
        case 4
            Na = 3;
        case 8
            Na = 9;
        case 16
            Na = 31;
        case 32
            Na = 102;
        case 64
            Na = 342;
        case 128
            Na = 1175;
        case 256
            Na = 4112;
        otherwise
            error("getNa: blksize error\n");
    end

end