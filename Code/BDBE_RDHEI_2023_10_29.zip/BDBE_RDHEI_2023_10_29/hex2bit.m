function [bitstream] = hex2bit(hexstream)
% 函数说明：16进制转二进制
% 输入：hexstream（16进制串）
% 输出：bitstream（二进制串）

    byte_len = length(hexstream);

    bitstream = zeros(byte_len, 4);
    value = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'];
    bitarr = [0,0,0,0; 0,0,0,1; 0,0,1,0; 0,0,1,1; 0,1,0,0; 0,1,0,1; 0,1,1,0; 0,1,1,1; 1,0,0,0; 1,0,0,1; 1,0,1,0; 1,0,1,1; 1,1,0,0; 1,1,0,1; 1,1,1,0; 1,1,1,1];
    
    for i = 1:16
        id = find(hexstream(:) == value(i));
        bitstream(id, :) = repmat(bitarr(i,:), length(id), 1);
    end
    bitstream = reshape(bitstream', 1, byte_len * 4);
end