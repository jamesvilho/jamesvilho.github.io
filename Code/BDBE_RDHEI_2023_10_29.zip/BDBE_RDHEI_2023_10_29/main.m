clear;
clc;

% I = imread("photo\baboon.png");
% I = imread("photo\boat.png");
% I = imread("photo\jetplane.png");
% I = imread("photo\lena.png");
% I = imread("photo\man.png");
I = imread("photo\peppers.png");

I = double(I);
[m, n] = size(I);

%% 图像加密
image_key = 'ffff567890abcdef'; image_iv  = 'f234567890abcdef';           % 图像加密秘钥 AES加密
disp("time: encryption");
tic
[E, ER] = encrypt(I, image_key, image_iv);
toc
fprintf("\n");

%% 数据嵌入
data_key = '0123456789abcdef'; data_iv  = 'fedcba9876543210';             % 数据加密秘钥 AES加密
disp("time: embed");
dataLen = 1 * m * n; 
embed_bits = randi([0 1], 1, dataLen);                                    % 待嵌入的秘密数据
tic 
EM = embed(E, embed_bits, data_key, data_iv);   
toc
fprintf("\n");

%% 数据提取
disp("time: extract");
tic
data = extract(EM, dataLen, data_key, data_iv); 
toc
disp("Lossless data extraction?");
isequal(data, embed_bits)
fprintf("\n");

%% 图像恢复
disp("time: recover");
tic
recI = recover(EM, image_key, image_iv);
toc
disp("Lossless image recovery?");
isequal(I, recI)

figure(1);
subplot(141);imshow(I,[]);title('原始图像');
subplot(142);imshow(E,[]);title('密文图像');
subplot(143);imshow(EM,[]);title('标记的密文图像');
subplot(144);imshow(recI,[]);title('恢复的图像');