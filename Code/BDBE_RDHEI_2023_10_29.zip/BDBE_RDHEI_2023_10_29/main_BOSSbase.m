clear;
clc;

pNum = 10000;
ER_BOSSbase = zeros(pNum, 1);
path = 'D:\BaiduNetdiskDownload\BossBase-1.01-cover\';

image_key = 'ffff567890abcdef'; image_iv  = 'f234567890abcdef';           % 图像加密秘钥 AES加密

data_key = '0123456789abcdef'; data_iv  = 'fedcba9876543210';             % 数据加密秘钥 AES加密

for pId = 1 : pNum
    pname = [path, num2str(pId), '.pgm'];
    disp(pname);
    I = imread(pname);
    I = double(I);
    [m, n] = size(I);

    %% 图像加密
    [E, ER_BOSSbase(pId)] = encrypt(I, image_key, image_iv);
    
    %% 数据嵌入
    dataLen = 0.5 * m * n; 
    embed_bits = randi([0 1], 1, dataLen);                                    % 待嵌入的秘密数据
    EM = embed(E, embed_bits, data_key, data_iv);   

    %% 数据提取
    data = extract(EM, dataLen, data_key, data_iv); 
    if ~isequal(data, embed_bits)
        error("extract error");
    end

    %% 图像恢复
    recI = recover(EM, image_key, image_iv);
    if ~isequal(I, recI)
        error("recover error");
    end
end

save('ER_BOSSbase.mat', 'ER_BOSSbase');
