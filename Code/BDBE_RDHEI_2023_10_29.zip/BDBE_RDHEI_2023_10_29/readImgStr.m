function [out] = readImgStr(I)
% 函数说明：图像转比特串（对于8位灰度图像I, 从高位面到低位面, 位面内按行扫描，得到比特串）
% 输入：I（8-bit 灰度图像）
% 输出：out（逐位面提取的比特串）

    [m, n] = size(I);
    pixels = m * n;
    I = reshape(I', pixels, 1); % 按行转为列向量
    
    out = zeros(pixels, 8);
    for i = 1:pixels
        out(i,:) = dec2bin(I(i,1), 8)-'0';
    end
    
    out = reshape(out, 8 * m * n, 1)';  % 从高位面到低位面,每个位面按行扫描,得到的行向量
    
end