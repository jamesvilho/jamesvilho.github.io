function [recI] = recover(EM, image_key, image_iv)
% 函数说明：图像恢复
% 输入：EM（标记的密文图像）, image_key & image_iv（图像加密秘钥）
% 输出：recI（恢复的图像）

    strImg = readImgStr(EM);    % 图像转二进制
    [m, n] = size(EM);
    
    %% SI解析
    % 1. 不可编码的位面个数 K
    pos = 1;
    len = 5;
    K = bit2dec(strImg(pos : pos+len-1));            
    pos = pos + len;
    
    % 2. 不可编码位面的下标 unId
    unId = zeros(1, K);     
    len = 5;
    for i = 1:K
        unId(i) = bit2dec(strImg(pos : pos+len-1)); 
        pos = pos + len;
    end
    
    % 可编码位面的下标 cId
    Ids = 1:18;
    is = ismember(Ids, unId);
    cId = Ids(~is);                                       
    Cnum = length(cId);
    
    % 3. 可编码的位面分块大小 blksizes
    blksizes = zeros(1, Cnum);
    len = 3;
    for i = 1:Cnum
        x = bit2dec(strImg(pos : pos+len-1));
        pos = pos + len;
        blksizes(i) = 2^(x+2);                             
    end
    
    % 4. 可编码位面的压缩结果长度 CLen
    CLen = zeros(1, Cnum);
    SumCLen = 0;
    
    len = ceil(log2(m * n/2));
    for i = 1:Cnum
        CLen(i) = bit2dec(strImg(pos : pos+len-1));
        SumCLen = SumCLen + CLen(i);
        pos = pos + len;
    end
    
    % 5. e∉[-128,127]的像素个数 keepNum
    len = ceil(log2(m*n));
    keepNum = bit2dec(strImg(pos : pos+len-1));
    pos = pos + len;
    
    %% 获取MI
    
    len_MI = keepNum * 8 + SumCLen + K * m/2 * n;      % MI = T||C||U
    len_EMI = ceil(len_MI/128) * 128;                  % AES加密后的长度
    EMI = strImg(pos : pos+len_EMI-1);                 % EMI的起始位置 pos
    
    MI = AES_dec(EMI, image_key, image_iv);            % AES解密
    
    %% MI解析
    % 误差e∉[-128,127]的像素的原值序列 T
    pos = 1;
    len = 8 * keepNum;
    T = MI(pos : pos+len-1);                        
    pos = pos + len;
    
    % 计算compressAns的各长度 compressLen
    compressLen = zeros(1, 18);
    compressLen(is) = m/2*n * ones(1, K);
    compressLen(~is) = CLen;

    % 设置分块大小 compressBlksize
    compressBlksize = zeros(1, 18);
    compressBlksize(is) = 1;
    compressBlksize(~is) = blksizes;
    
    % 设置位面的编码结果 compressAns
    len = sum(compressLen);
    compressAns = MI(pos:pos+len-1);
    compressAns = mat2cell(compressAns, 1, compressLen);

    %% BDBE recovery

    [EI8, location_map] = BDBE_rec(compressBlksize, compressAns, m, n);

    [recI] = generateEI_rec(EI8, location_map, T);

end