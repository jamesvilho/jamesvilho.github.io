function [I] = strWriteImg(str_01, m, n)
% 函数说明：比特串转图像（将比特串从高位面到低位面, 位面内按行写入，得到8位灰度图像I）
% 输入：str_01（比特串）, m（图像的行数）, n（图像的列数）
% 输出：I（8-bit 灰度图像）

    if length(str_01) ~= 8 * m * n
        error("strWriteImg: length error\n");
    end
    
    pixels = m * n;
    str_01 = reshape(str_01, pixels, 8);  % 均分为8份 最高位面(第一列), 最低位面(第8列)
    
    I = zeros(pixels, 1);
    for i = 1:pixels
        v = str_01(i,:);
        I(i, :) = v(1) * 2^7 + v(2) * 2^6 + v(3) * 2^5 + v(4) * 2^4 + v(5) * 2^3 + v(6) * 2^2 + v(7) * 2^1 + v(8);
    end
    
    I = reshape(I, n, m)';

end