function [out] = transCode(e)
% 函数说明：预测误差转换
% 输入：e（原始误差值）
% 输出：out（转换后的误差值）

    out = abs(e) * 2;
    if e < 0
        out = out - 1;
    end
    
end