function [e] = transCode_rec(value)
% 函数说明：预测误差的恢复
% 输入：value（转换后的误差值）
% 输出：e（原始误差值）

    sign = bitand(value, 1);
    
    e = floor(value/2);
    if sign == 1
        e = e + 1;
        e = e * (-1);
    end
    
end